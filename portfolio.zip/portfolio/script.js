
$(function(){
    var box    = $(".side");
    var boxTop = box.offset().top;
    $(window).scroll(function () {
        if($(window).scrollTop() >= boxTop) {
            box.addClass("fixed");
			$(".header").css("margin-top","0px");
        } else {
            box.removeClass("fixed");
			$(".header").css("margin-top","0px");
        }
    });
});

$(function(){
    $('.side').css({'height':$(window).height()});
    $(window).on('resize',function(){
        winH = $(window).height();
        $('.side').outerHeight(winH);
    });
});


$(function(){
    $(window).scroll(function (){
      $(".sample-a").each(function(){
        var imgPos = $(this).offset().top;
        var scroll = $(window).scrollTop();
        var windowHeight = $(window).height();
        if (scroll > imgPos - windowHeight + windowHeight/5){
          $(this).addClass("fade_on-a");
        } else {
          $(this).removeClass("fade_on-a");
        }
      });
    });
  });

  $(function(){
    $(window).scroll(function (){
      $(".sample-b").each(function(){
        var imgPos = $(this).offset().top;
        var scroll = $(window).scrollTop();
        var windowHeight = $(window).height();
        if (scroll > imgPos - windowHeight + windowHeight/5){
          $(this).addClass("fade_on-b");
        } else {
          $(this).removeClass("fade_on-b");
        }
      });
    });
  });

  $(function(){
    $(window).scroll(function (){
      $(".sample-c").each(function(){
        var imgPos = $(this).offset().top;
        var scroll = $(window).scrollTop();
        var windowHeight = $(window).height();
        if (scroll > imgPos - windowHeight + windowHeight/5){
          $(this).addClass("fade_on-c");
        } else {
          $(this).removeClass("fade_on-c");
        }
      });
    });
  });


  $(function(){
    $(window).scroll(function (){
      $(".sample-d").each(function(){
        var imgPos = $(this).offset().top;
        var scroll = $(window).scrollTop();
        var windowHeight = $(window).height();
        if (scroll > imgPos - windowHeight + windowHeight/5){
          $(this).addClass("fade_on-d");
        } else {
          $(this).removeClass("fade_on-d");
        }
      });
    });
  });

